package main
import "fmt"
type person struct {
	name string
	sex  string
	age  int
}
func main() {
	var p1 person
	p1.name = "xxx"
	p1.sex = "xxx"
	p1.age = 1
	fmt.Println(p1)
	var p2 person = person{"xxx", "xxx", 2}
	fmt.Println(p2)
}
